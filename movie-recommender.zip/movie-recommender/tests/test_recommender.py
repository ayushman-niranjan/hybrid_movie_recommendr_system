"""Run: python -m pytest tests   (needs pytest). Uses synthetic data, no download."""
import subprocess, sys, pathlib
import pytest

ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from recommender import HybridRecommender


@pytest.fixture(scope="module")
def rec(tmp_path_factory):
    d = tmp_path_factory.mktemp("d")
    subprocess.run([sys.executable, str(ROOT / "dev/make_sample_data.py"), str(d)], check=True)
    pkl = d / "model.pkl"
    subprocess.run([sys.executable, str(ROOT / "build_model.py"), "--data-dir", str(d), "--out", str(pkl)], check=True)
    return HybridRecommender(str(pkl))


@pytest.mark.parametrize("alpha", [0.0, 0.5, 1.0])
def test_valid_output(rec, alpha):
    liked = [rec.titles[10], rec.titles[20]]
    out, _ = rec.recommend(liked, alpha=alpha, top_n=8)
    assert len(out) == 8 and not set(out.title) & set(liked)
    assert out.hybrid.notna().all() and out.hybrid.between(0, 1).all()
    assert out.hybrid.is_monotonic_decreasing


def test_content_only_shares_genre(rec):
    g = set(rec.movies.genres[10].split("|"))
    out, _ = rec.recommend([rec.titles[10]], alpha=1.0, top_n=10)
    assert all(g & set(x.split("|")) for x in out.genres)
