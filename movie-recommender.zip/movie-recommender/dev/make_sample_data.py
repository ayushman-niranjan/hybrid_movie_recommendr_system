"""Generate a tiny synthetic dataset in MovieLens format, ONLY for offline testing.

    python dev/make_sample_data.py dev/sample
    python build_model.py --data-dir dev/sample --out model.pkl
"""
import os
import sys

import numpy as np
import pandas as pd

out = sys.argv[1] if len(sys.argv) > 1 else "dev/sample"
os.makedirs(out, exist_ok=True)
rng = np.random.default_rng(0)
G = ["Action", "Comedy", "Drama", "Sci-Fi", "Romance", "Horror", "Animation", "Thriller"]

n_movies, n_users = 400, 150
movies = pd.DataFrame({
    "movieId": range(1, n_movies + 1),
    "title": [f"Film {i:03d} ({rng.integers(1980, 2020)})" for i in range(1, n_movies + 1)],
    "genres": ["|".join(rng.choice(G, rng.integers(1, 4), replace=False)) for _ in range(n_movies)],
})
taste = rng.random((n_users, len(G)))
rows = []
for u in range(1, n_users + 1):
    for m in rng.choice(n_movies, rng.integers(20, 80), replace=False):
        gs = movies.genres[m].split("|")
        aff = np.mean([taste[u - 1, G.index(g)] for g in gs])
        rows.append((u, m + 1, float(np.clip(round((1 + 4 * aff + rng.normal(0, .5)) * 2) / 2, .5, 5))))
pd.DataFrame(rows, columns=["userId", "movieId", "rating"]).to_csv(f"{out}/ratings.csv", index=False)
movies.to_csv(f"{out}/movies.csv", index=False)
pd.DataFrame({"movieId": [1, 2], "tag": ["space opera", "heist"]}).to_csv(f"{out}/tags.csv", index=False)
print("wrote", out)
